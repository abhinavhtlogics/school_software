require('./bootstrap');
require('./components/main-component.js')