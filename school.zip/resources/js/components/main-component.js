import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'

import Login from './login';
import Users from './admin/pages/Users';

function Hello() {
   
  return (
<Router>
<>
<Routes>
        <Route path='/' exact component={Login}></Route>
        <Route path="login" element={<Login />} />
        <Route path="users" element={<Users />} />
    </Routes>

</>
</Router>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<Hello />);

export default Hello